from django.apps import AppConfig


class DongTaiModelsConfig(AppConfig):
    name = 'dongtai_models'
