#!/usr/bin/env python
# -*- coding:utf-8 -*-
# author:owefsad
# datetime:2021/1/25 下午6:43
# software: PyCharm
# project: dongtai-models

from .user import User
